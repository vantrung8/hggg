// NTRUNG VN — UIKit menu redesign patch
// Replace the ModMenuWindow interface and implementation in the original .mm with this file's content.
// Keep the existing ESPTarget, ESPLayer, polling and game logic unchanged.

@interface ModMenuWindow : UIWindow
@property(nonatomic,strong) UIView *menuView;
@property(nonatomic,strong) UIButton *floatingBtn;
@property(nonatomic,strong) UISegmentedControl *tabControl;
@property(nonatomic,strong) UIView *espView;
@property(nonatomic,strong) UIView *aimView;
@property(nonatomic,strong) UIView *infoView;
@property(nonatomic,strong) ESPLayer *espLayer;
@property(nonatomic,strong) UIButton *checkESP,*espBoxBtn,*espLineBtn,*espNameBtn,*espDistBtn,*espHpBtn,*espCountBtn,*espBotBtn;
@property(nonatomic,strong) UIButton *aimbotBtn,*silentAimBtn,*aimKillBtn,*skipKnockedBtn;
@property(nonatomic,strong) UISegmentedControl *bodyPartSegment,*aimModeSegment;
@property(nonatomic,strong) UISlider *fovSlider;
- (void)tickESP;
@end

@implementation ModMenuWindow
static UIColor *NVColor(unsigned rgb) { return [UIColor colorWithRed:((rgb>>16)&255)/255.0 green:((rgb>>8)&255)/255.0 blue:(rgb&255)/255.0 alpha:1]; }
- (UILabel *)label:(NSString *)s frame:(CGRect)f size:(CGFloat)z bold:(BOOL)b color:(UIColor *)c parent:(UIView *)v {
 UILabel *l=[[UILabel alloc]initWithFrame:f]; l.text=s;l.textColor=c;l.font=b?[UIFont systemFontOfSize:z weight:UIFontWeightSemibold]:[UIFont systemFontOfSize:z];l.adjustsFontSizeToFitWidth=YES;[v addSubview:l];return l;
}
- (UIView *)panel:(CGRect)r parent:(UIView *)v { UIView *p=[[UIView alloc]initWithFrame:r];p.backgroundColor=NVColor(0x151D2B);p.layer.cornerRadius=13;p.layer.borderWidth=1;p.layer.borderColor=NVColor(0x273346).CGColor;[v addSubview:p];return p; }
- (void)loadLogo:(UIImageView *)iv {
 NSURL *u=[NSURL URLWithString:@"https://cdn.upanhlaylink.com/i/hMrZMgDK.png"];
 NSURLSessionDataTask *task=[[NSURLSession sharedSession]dataTaskWithURL:u completionHandler:^(NSData *d,NSURLResponse *r,NSError *e){if(e||!d)return;UIImage *im=[UIImage imageWithData:d];if(im)dispatch_async(dispatch_get_main_queue(),^{iv.image=im;});}];[task resume];
}
- (instancetype)initWithFrame:(CGRect)frame {
 if(!(self=[super initWithFrame:frame]))return nil;
 self.windowLevel=UIWindowLevelAlert+100;self.backgroundColor=UIColor.clearColor;
 self.rootViewController=[UIViewController new];self.rootViewController.view.backgroundColor=UIColor.clearColor;
 CGFloat sw=frame.size.width,sh=frame.size.height,mw=MIN(370,sw-24),mh=MIN(455,sh-35);
 self.espLayer=[[ESPLayer alloc]initWithFrame:CGRectMake(0,0,sw,sh)];self.espLayer.hidden=YES;[self.rootViewController.view addSubview:self.espLayer];
 self.menuView=[[UIView alloc]initWithFrame:CGRectMake((sw-mw)/2,(sh-mh)/2,mw,mh)];self.menuView.backgroundColor=NVColor(0x0C121E);self.menuView.layer.cornerRadius=20;self.menuView.layer.borderWidth=1;self.menuView.layer.borderColor=NVColor(0x34485F).CGColor;self.menuView.layer.shadowColor=UIColor.blackColor.CGColor;self.menuView.layer.shadowOpacity=.55;self.menuView.layer.shadowRadius=24;[self.rootViewController.view addSubview:self.menuView];
 UIView *header=[[UIView alloc]initWithFrame:CGRectMake(0,0,mw,79)];[self.menuView addSubview:header];
 UIImageView *logo=[[UIImageView alloc]initWithFrame:CGRectMake(18,17,42,42)];logo.contentMode=UIViewContentModeScaleAspectFill;logo.clipsToBounds=YES;logo.layer.cornerRadius=12;logo.backgroundColor=NVColor(0x1B3448);[header addSubview:logo];[self loadLogo:logo];
 [self label:@"NTRUNG VN" frame:CGRectMake(71,16,mw-125,25) size:19 bold:YES color:UIColor.whiteColor parent:header];
 [self label:@"PREMIUM CONTROL PANEL" frame:CGRectMake(72,41,mw-125,16) size:10 bold:YES color:NVColor(0x53D5E9) parent:header];
 UIButton *close=[UIButton buttonWithType:UIButtonTypeSystem];close.frame=CGRectMake(mw-48,20,30,30);close.layer.cornerRadius=10;close.backgroundColor=NVColor(0x202B3A);[close setTitle:@"×" forState:UIControlStateNormal];[close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];close.titleLabel.font=[UIFont systemFontOfSize:23];[close addTarget:self action:@selector(closeMenu) forControlEvents:UIControlEventTouchUpInside];[header addSubview:close];
 UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];[header addGestureRecognizer:pan];
 UIView *line=[[UIView alloc]initWithFrame:CGRectMake(16,77,mw-32,1)];line.backgroundColor=NVColor(0x283548);[self.menuView addSubview:line];
 self.tabControl=[[UISegmentedControl alloc]initWithItems:@[@"ESP",@"AIMBOT",@"INFO"]];self.tabControl.frame=CGRectMake(16,91,mw-32,35);self.tabControl.selectedSegmentIndex=0;self.tabControl.backgroundColor=NVColor(0x182333);self.tabControl.selectedSegmentTintColor=NVColor(0x29B8D4);[self.tabControl setTitleTextAttributes:@{NSForegroundColorAttributeName:UIColor.whiteColor,NSFontAttributeName:[UIFont boldSystemFontOfSize:11]} forState:UIControlStateNormal];[self.tabControl addTarget:self action:@selector(tabChanged:) forControlEvents:UIControlEventValueChanged];[self.menuView addSubview:self.tabControl];
 CGRect content=CGRectMake(16,138,mw-32,mh-151);
 self.espView=[[UIView alloc]initWithFrame:content];[self.menuView addSubview:self.espView];
 self.aimView=[[UIView alloc]initWithFrame:content];self.aimView.hidden=YES;[self.menuView addSubview:self.aimView];
 self.infoView=[[UIView alloc]initWithFrame:content];self.infoView.hidden=YES;[self.menuView addSubview:self.infoView];
 CGFloat w=content.size.width,col=(w-12)/2;
 [self label:@"VISUAL SETTINGS" frame:CGRectMake(3,0,w,18) size:11 bold:YES color:NVColor(0x8A9BB3) parent:self.espView];
 self.checkESP=[self makeCheckBox:self.espView x:0 y:25 w:w t:@"Enable ESP" a:@selector(onESPTapped)];
 self.espBoxBtn=[self makeCheckBox:self.espView x:0 y:73 w:col t:@"Box" a:@selector(onEspBoxTapped)];
 self.espLineBtn=[self makeCheckBox:self.espView x:col+12 y:73 w:col t:@"Line" a:@selector(onEspLineTapped)];
 self.espNameBtn=[self makeCheckBox:self.espView x:0 y:121 w:col t:@"Name" a:@selector(onEspNameTapped)];
 self.espDistBtn=[self makeCheckBox:self.espView x:col+12 y:121 w:col t:@"Distance" a:@selector(onEspDistTapped)];
 self.espHpBtn=[self makeCheckBox:self.espView x:0 y:169 w:col t:@"Health" a:@selector(onEspHpTapped)];
 self.espCountBtn=[self makeCheckBox:self.espView x:col+12 y:169 w:col t:@"Count" a:@selector(onEspCountTapped)];
 self.espBotBtn=[self makeCheckBox:self.espView x:0 y:217 w:w t:@"Show Bot" a:@selector(onEspBotTapped)];
 [self label:@"TARGET SETTINGS" frame:CGRectMake(3,0,w,18) size:11 bold:YES color:NVColor(0x8A9BB3) parent:self.aimView];
 self.aimbotBtn=[self makeCheckBox:self.aimView x:0 y:23 w:w t:@"Enable Aimbot" a:@selector(onAimbotTapped)];
 self.silentAimBtn=[self makeCheckBox:self.aimView x:0 y:68 w:col t:@"Silent Aim" a:@selector(onSilentAimTapped)];
 self.aimKillBtn=[self makeCheckBox:self.aimView x:col+12 y:68 w:col t:@"AimKill" a:@selector(onAimKillTapped)];
 [self label:@"TARGET PART" frame:CGRectMake(3,116,w,15) size:10 bold:YES color:NVColor(0xA7B6C8) parent:self.aimView];
 self.bodyPartSegment=[[UISegmentedControl alloc]initWithItems:@[@"Head",@"Neck",@"Body"]];self.bodyPartSegment.frame=CGRectMake(0,134,w,31);self.bodyPartSegment.selectedSegmentIndex=g_aimBodyPart;[self.bodyPartSegment addTarget:self action:@selector(bodyPartChanged:) forControlEvents:UIControlEventValueChanged];[self.aimView addSubview:self.bodyPartSegment];
 [self label:@"ACTIVATION MODE" frame:CGRectMake(3,174,w,15) size:10 bold:YES color:NVColor(0xA7B6C8) parent:self.aimView];
 self.aimModeSegment=[[UISegmentedControl alloc]initWithItems:@[@"Always",@"Fire",@"Scope",@"F+S"]];self.aimModeSegment.frame=CGRectMake(0,191,w,31);self.aimModeSegment.selectedSegmentIndex=g_aimMode;[self.aimModeSegment addTarget:self action:@selector(aimModeChanged:) forControlEvents:UIControlEventValueChanged];[self.aimView addSubview:self.aimModeSegment];
 self.skipKnockedBtn=[self makeCheckBox:self.aimView x:0 y:232 w:w t:@"Bỏ qua địch gục" a:@selector(onSkipKnockedTapped)];
 [self label:@"FOV SIZE" frame:CGRectMake(3,278,w,15) size:10 bold:YES color:NVColor(0xA7B6C8) parent:self.aimView];
 self.fovSlider=[[UISlider alloc]initWithFrame:CGRectMake(0,295,w,25)];self.fovSlider.minimumValue=30;self.fovSlider.maximumValue=500;self.fovSlider.value=g_fov;self.fovSlider.minimumTrackTintColor=NVColor(0x29B8D4);[self.fovSlider addTarget:self action:@selector(fovChanged:) forControlEvents:UIControlEventValueChanged];[self.aimView addSubview:self.fovSlider];
 UIView *profile=[self panel:CGRectMake(0,5,w,96) parent:self.infoView];
 [self label:@"DEVELOPER" frame:CGRectMake(17,13,w-34,18) size:10 bold:YES color:NVColor(0x53D5E9) parent:profile];
 [self label:@"Nguyễn Trung" frame:CGRectMake(17,37,w-34,31) size:23 bold:YES color:UIColor.whiteColor parent:profile];
 [self infoLink:@"ADMIN  ·  @nguyentrungios8" url:@"https://t.me/nguyentrungios8" y:114 width:w];
 [self infoLink:@"CHANNEL  ·  @channelnguyentrung" url:@"https://t.me/channelnguyentrung" y:170 width:w];
 [self label:@"NTRUNG VN  •  PREMIUM UI" frame:CGRectMake(3,239,w-6,20) size:10 bold:YES color:NVColor(0x6F8299) parent:self.infoView];
 for(UIButton *b in @[self.checkESP,self.espBoxBtn,self.espLineBtn,self.espNameBtn,self.espDistBtn,self.espHpBtn,self.espCountBtn,self.espBotBtn]) [self setCheckOn:b on:(b!=self.espBotBtn)];
 for(UIButton *b in @[self.aimbotBtn,self.silentAimBtn,self.aimKillBtn]) [self setCheckOn:b on:NO];[self setCheckOn:self.skipKnockedBtn on:g_skipKnocked];
 self.floatingBtn=[UIButton buttonWithType:UIButtonTypeCustom];self.floatingBtn.frame=CGRectMake(sw-68,100,52,52);self.floatingBtn.backgroundColor=NVColor(0x0D1D2C);self.floatingBtn.layer.cornerRadius=26;self.floatingBtn.layer.borderWidth=2;self.floatingBtn.layer.borderColor=NVColor(0x29B8D4).CGColor;[self.floatingBtn addTarget:self action:@selector(openMenu) forControlEvents:UIControlEventTouchUpInside];self.floatingBtn.hidden=YES;[self.rootViewController.view addSubview:self.floatingBtn];
 UIImageView *floatingLogo=[[UIImageView alloc]initWithFrame:CGRectMake(6,6,40,40)];floatingLogo.layer.cornerRadius=20;floatingLogo.clipsToBounds=YES;floatingLogo.contentMode=UIViewContentModeScaleAspectFill;floatingLogo.userInteractionEnabled=NO;[self.floatingBtn addSubview:floatingLogo];[self loadLogo:floatingLogo];
 UIPanGestureRecognizer *fp=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handleFloatPan:)];[self.floatingBtn addGestureRecognizer:fp];return self;
}
- (void)infoLink:(NSString *)title url:(NSString *)url y:(CGFloat)y width:(CGFloat)w {UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];b.frame=CGRectMake(0,y,w,46);b.layer.cornerRadius=12;b.backgroundColor=NVColor(0x151D2B);b.layer.borderWidth=1;b.layer.borderColor=NVColor(0x273346).CGColor;[b setTitle:title forState:UIControlStateNormal];[b setTitleColor:NVColor(0xDDECF7) forState:UIControlStateNormal];b.titleLabel.font=[UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];b.accessibilityIdentifier=url;[b addTarget:self action:@selector(openInfoLink:) forControlEvents:UIControlEventTouchUpInside];[self.infoView addSubview:b];}
- (void)openInfoLink:(UIButton *)b {NSURL *u=[NSURL URLWithString:b.accessibilityIdentifier];if(u)[[UIApplication sharedApplication]openURL:u options:@{} completionHandler:nil];}
- (UIButton *)makeCheckBox:(UIView *)p x:(CGFloat)x y:(CGFloat)y w:(CGFloat)w t:(NSString *)t a:(SEL)a {UIView *tile=[self panel:CGRectMake(x,y,w,39) parent:p];UIButton *b=[UIButton buttonWithType:UIButtonTypeCustom];b.frame=CGRectMake(9,8,23,23);b.layer.cornerRadius=7;b.layer.borderWidth=1;b.layer.borderColor=NVColor(0x53657A).CGColor;[b addTarget:self action:a forControlEvents:UIControlEventTouchUpInside];[tile addSubview:b];[self label:t frame:CGRectMake(39,7,w-44,25) size:12 bold:YES color:NVColor(0xE6EFF8) parent:tile];UIButton *tap=[UIButton buttonWithType:UIButtonTypeCustom];tap.frame=CGRectMake(34,0,w-34,39);[tap addTarget:self action:a forControlEvents:UIControlEventTouchUpInside];[tile addSubview:tap];return b;}
- (void)setCheckOn:(UIButton *)b on:(BOOL)o {b.backgroundColor=o?NVColor(0x29B8D4):NVColor(0x263448);[b setTitle:o?@"✓":@"" forState:UIControlStateNormal];[b setTitleColor:NVColor(0x08111D) forState:UIControlStateNormal];b.titleLabel.font=[UIFont boldSystemFontOfSize:15];}
- (BOOL)pointInside:(CGPoint)p withEvent:(UIEvent *)e {if(!self.menuView.hidden&&[self.menuView pointInside:[self convertPoint:p toView:self.menuView] withEvent:e])return YES;if(!self.floatingBtn.hidden&&[self.floatingBtn pointInside:[self convertPoint:p toView:self.floatingBtn] withEvent:e])return YES;return NO;}
- (void)tabChanged:(UISegmentedControl *)s {self.espView.hidden=s.selectedSegmentIndex!=0;self.aimView.hidden=s.selectedSegmentIndex!=1;self.infoView.hidden=s.selectedSegmentIndex!=2;}
- (void)fovChanged:(UISlider *)s {g_fov=s.value;}
- (void)bodyPartChanged:(UISegmentedControl *)s {g_aimBodyPart=(AimBodyPart)s.selectedSegmentIndex;}
- (void)aimModeChanged:(UISegmentedControl *)s {g_aimMode=(AimMode)s.selectedSegmentIndex;}
- (void)onESPTapped {g_master=!g_master;[self setCheckOn:self.checkESP on:g_master];}
- (void)onEspBoxTapped {g_box=!g_box;[self setCheckOn:self.espBoxBtn on:g_box];}
- (void)onEspLineTapped {g_line=!g_line;[self setCheckOn:self.espLineBtn on:g_line];}
- (void)onEspNameTapped {g_name=!g_name;[self setCheckOn:self.espNameBtn on:g_name];}
- (void)onEspDistTapped {g_dist=!g_dist;[self setCheckOn:self.espDistBtn on:g_dist];}
- (void)onEspHpTapped {g_hp=!g_hp;[self setCheckOn:self.espHpBtn on:g_hp];}
- (void)onEspCountTapped {g_count=!g_count;[self setCheckOn:self.espCountBtn on:g_count];}
- (void)onEspBotTapped {g_bot=!g_bot;[self setCheckOn:self.espBotBtn on:g_bot];}
- (void)onAimbotTapped {g_aimbot=!g_aimbot;[self setCheckOn:self.aimbotBtn on:g_aimbot];}
- (void)onSilentAimTapped {g_silentAim=!g_silentAim;[self setCheckOn:self.silentAimBtn on:g_silentAim];if(g_silentAim)StartSilentAimThread();}
- (void)onAimKillTapped {g_aimKill=!g_aimKill;[self setCheckOn:self.aimKillBtn on:g_aimKill];}
- (void)onSkipKnockedTapped {g_skipKnocked=!g_skipKnocked;[self setCheckOn:self.skipKnockedBtn on:g_skipKnocked];}
- (void)closeMenu {self.menuView.hidden=YES;self.floatingBtn.hidden=NO;}
- (void)openMenu {self.menuView.hidden=NO;self.floatingBtn.hidden=YES;}
- (void)handlePan:(UIPanGestureRecognizer *)s {CGPoint t=[s translationInView:self.rootViewController.view];self.menuView.center=CGPointMake(self.menuView.center.x+t.x,self.menuView.center.y+t.y);[s setTranslation:CGPointZero inView:self.rootViewController.view];}
- (void)handleFloatPan:(UIPanGestureRecognizer *)s {CGPoint t=[s translationInView:self.rootViewController.view];self.floatingBtn.center=CGPointMake(self.floatingBtn.center.x+t.x,self.floatingBtn.center.y+t.y);[s setTranslation:CGPointZero inView:self.rootViewController.view];}
- (void)tickESP {if(!g_master){self.espLayer.hidden=YES;return;}self.espLayer.hidden=NO;os_unfair_lock_lock(&g_lock);self.espLayer.targets=[g_targets copy];NSUInteger count=0;for(ESPTarget *t in g_targets.allValues)if(!t.isGhost)count++;os_unfair_lock_unlock(&g_lock);self.espLayer.countText=g_count?[NSString stringWithFormat:@"Player : %lu",(unsigned long)count]:@"";self.espLayer.showLine=g_line;self.espLayer.showBox=g_box;self.espLayer.showName=g_name;self.espLayer.showDist=g_dist;self.espLayer.showHp=g_hp;self.espLayer.showAimFov=(g_aimbot||g_silentAim||g_aimKill);[self.espLayer setNeedsDisplay];}
@end
