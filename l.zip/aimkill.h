#pragma once
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
#include <unistd.h>
#include "Offsets.h"

struct AimKill_Vec3 { float x, y, z; };
struct AimKill_Quat { float x, y, z, w; };

struct AimKill_PlayerID {
    uint32_t m_Value;
    uint32_t m_ID;
    uint8_t  m_TeamID;
    uint8_t  m_ShortID;
    uint8_t  _pad0[6];
    uint64_t m_IDMask;
    uint32_t _field18;
    uint32_t _pad1;
};

namespace AimKill {

    typedef void* (*F_1x)(void*);
    typedef void* (*F_fire)(void*, void*);
    typedef void  (*F_setRot)(void* self, AimKill_Quat q, bool snap);
    typedef int (*F_takeDamage)(void*, int, AimKill_PlayerID, void*, int,
                                AimKill_Vec3, AimKill_Vec3, void*, void*, uint32_t);

    static F_1x         getWeaponOnHand      = nullptr;
    static F_1x         getHeadCollider      = nullptr;
    static F_1x         getGameObject        = nullptr;
    static F_setRot     setAimRotation       = nullptr;
    static F_takeDamage takeDamage           = nullptr;
    static F_fire       startFiring          = nullptr;
    static F_fire       stopFire             = nullptr;
    static F_fire       startWholeBodyFiring = nullptr;

    static void*  g_cachedWeapon = nullptr;
    static double g_lastFire     = 0.0;
    static bool   g_inited       = false;

    static inline double NowSec() {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        return tv.tv_sec + tv.tv_usec / 1000000.0;
    }

    static inline bool Valid(void* p) {
        uintptr_t v = (uintptr_t)p;
        return v >= 0x100000000ULL && v <= 0x7FFFFFFFFFFFULL;
    }

    static inline AimKill_Quat LookRotation(AimKill_Vec3 f, AimKill_Vec3 up) {
        float fl = sqrtf(f.x*f.x + f.y*f.y + f.z*f.z);
        if (fl < 0.0001f) return {0,0,0,1};
        f.x /= fl; f.y /= fl; f.z /= fl;
        float rx = up.y*f.z - up.z*f.y;
        float ry = up.z*f.x - up.x*f.z;
        float rz = up.x*f.y - up.y*f.x;
        float rl = sqrtf(rx*rx + ry*ry + rz*rz);
        if (rl < 0.0001f) return {0,0,0,1};
        rx /= rl; ry /= rl; rz /= rl;
        float ux = f.y*rz - f.z*ry;
        float uy = f.z*rx - f.x*rz;
        float uz = f.x*ry - f.y*rx;
        AimKill_Quat q;
        q.w = sqrtf(1.0f + rx + uy + f.z) * 0.5f;
        if (q.w < 0.0001f) return {0,0,0,1};
        q.x = (uz - f.y) / (4.0f * q.w);
        q.y = (f.x - rz) / (4.0f * q.w);
        q.z = (ry - ux) / (4.0f * q.w);
        return q;
    }

    static inline void InitOnce(uintptr_t base) {
        if (g_inited) return;
        g_inited = true;
        getWeaponOnHand      = (F_1x)         (base + RVA_Player_GetWeaponOnHand);
        getHeadCollider      = (F_1x)         (base + RVA_Player_GetHeadCollider);
        getGameObject        = (F_1x)         (base + RVA_Component_get_gameObject);
        setAimRotation       = (F_setRot)     (base + RVA_Player_SetAimRotation);
        takeDamage           = (F_takeDamage) (base + RVA_Player_TakeDamage);
        startFiring          = (F_fire)       (base + RVA_Player_StartFiring);
        stopFire             = (F_fire)       (base + RVA_Player_StopFire);
        startWholeBodyFiring = (F_fire)       (base + RVA_Player_StartWholeBodyFiring);
    }

    static inline void Run(uintptr_t base, void* local, void* enemy,
                           AimKill_Vec3 localHead, AimKill_Vec3 enemyHead) {
        if (!local || !enemy || local == enemy) return;
        InitOnce(base);
        if (!startFiring || !stopFire) return;

        double now = NowSec();
        if (now - g_lastFire < 0.20) return;
        g_lastFire = now;

        void* weapon = getWeaponOnHand(local);
        if (!Valid(weapon)) {
            if (!Valid(g_cachedWeapon)) return;
            weapon = g_cachedWeapon;
        } else {
            g_cachedWeapon = weapon;
        }
        if (!Valid(weapon)) return;

        int baseDamage = 9999;
        void* wparams = *(void**)((uintptr_t)weapon + OFFSET_Weapon_BaseDamagePtr);
        if (Valid(wparams)) {
            int d = *(int*)((uintptr_t)wparams + OFFSET_WeaponParams_BaseDamage);
            if (d > 0 && d < 100000) baseDamage = d;
        }

        if (enemyHead.x == 0 && enemyHead.y == 0 && enemyHead.z == 0) return;
        if (localHead.x == 0 && localHead.y == 0 && localHead.z == 0) return;

        void* objectPool = *(void**)((uintptr_t)local + OFFSET_Player_ObjectPool);
        if (!Valid(objectPool)) return;

        void* headCollider = getHeadCollider(enemy);
        if (!Valid(headCollider)) return;
        void* hitGO = getGameObject(headCollider);
        if (!Valid(hitGO)) return;

        float dx = enemyHead.x - localHead.x;
        float dy = enemyHead.y - localHead.y;
        float dz = enemyHead.z - localHead.z;
        float dist = sqrtf(dx*dx + dy*dy + dz*dz);
        AimKill_Vec3 dir = {0, 0, 0};
        if (dist > 0.0001f) {
            float inv = 1.0f / dist;
            dir.x = dx * inv; dir.y = dy * inv; dir.z = dz * inv;
        }

        char* p = (char*)objectPool;
        *(void**)(p + OFFSET_Pool_HitGameObject)      = hitGO;
        *(void**)(p + OFFSET_Pool_HitCollider)        = headCollider;
        *(AimKill_Vec3*)(p + OFFSET_Pool_HitLocation) = enemyHead;
        *(AimKill_Vec3*)(p + OFFSET_Pool_RayDir)      = dir;
        *(AimKill_Vec3*)(p + OFFSET_Pool_RayDir2)     = dir;
        *(AimKill_Vec3*)(p + OFFSET_Pool_StartPos)    = localHead;
        *(int*)(p + OFFSET_Pool_Damage)               = baseDamage * 10;
        *(float*)(p + OFFSET_Pool_Distance)           = dist;
        *(int*)(p + OFFSET_Pool_Flags60)              = 1;
        *(int*)(p + OFFSET_Pool_Flag64)               = 1;
        *(bool*)(p + OFFSET_Pool_Flag70)              = true;
        *(bool*)(p + OFFSET_Pool_Flag71)              = true;

        AimKill_Quat oldRot = {0,0,0,1};
        memcpy(&oldRot, (void*)((uintptr_t)local + OFFSET_Player_CurrentAimRotation), sizeof(AimKill_Quat));

        AimKill_Quat targetRot = LookRotation(dir, {0, 1, 0});

        if (setAimRotation) {
            setAimRotation(local, targetRot, true);
            usleep(16000);
        }

        startFiring(local, weapon);
        startWholeBodyFiring(local, weapon);

        if (takeDamage) {
            AimKill_PlayerID localId;
            memcpy(&localId, (void*)((uintptr_t)local + OFFSET_Player_PlayerID), sizeof(AimKill_PlayerID));

            void* damageInfo = nullptr;
            void* attrs = *(void**)((uintptr_t)local + OFFSET_Player_Attributes);
            if (Valid(attrs)) {
                void* dctx = *(void**)((uintptr_t)attrs + OFFSET_PlayerAttributes_DamageContext);
                if (Valid(dctx)) {
                    damageInfo = *(void**)((uintptr_t)dctx + OFFSET_DamageContext_DamageInfo);
                }
            }

            int killDmg = baseDamage * 10;
            if (killDmg < 9999) killDmg = 9999;

            AimKill_Vec3 lh = localHead;
            AimKill_Vec3 eh = enemyHead;

            takeDamage(enemy, killDmg, localId, damageInfo, -1,
                       lh, eh, nullptr, nullptr, 0);
        }

        usleep(16000);
        stopFire(local, weapon);

        if (setAimRotation) {
            setAimRotation(local, oldRot, true);
        }
    }
}