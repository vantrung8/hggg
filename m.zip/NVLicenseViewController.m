#import "NVLicenseViewController.h"
#import "NVLicenseManager.h"
@interface NVLicenseViewController ()
@property(nonatomic,strong) UITextField *keyField;

@property(nonatomic,strong) UIButton *activateButton;
@end
@implementation NVLicenseViewController
- (void)viewDidLoad { [super viewDidLoad]; self.view.backgroundColor=[UIColor colorWithRed:.05 green:.08 blue:.13 alpha:1];
 UILabel *title=[[UILabel alloc]init];title.translatesAutoresizingMaskIntoConstraints=NO;title.text=@"NTRUNG VN";title.textColor=UIColor.whiteColor;title.font=[UIFont boldSystemFontOfSize:28];title.textAlignment=NSTextAlignmentCenter;
 UILabel *subtitle=[[UILabel alloc]init];subtitle.translatesAutoresizingMaskIntoConstraints=NO;subtitle.text=@"KÍCH HOẠT LICENSE ONLINE";subtitle.textColor=[UIColor colorWithRed:.3 green:.82 blue:.9 alpha:1];subtitle.font=[UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];subtitle.textAlignment=NSTextAlignmentCenter;
 self.keyField=[UITextField new];self.keyField.translatesAutoresizingMaskIntoConstraints=NO;self.keyField.placeholder=@"NV-XXXXXXXX-XXXXXXXX-XXXXXXXX";self.keyField.autocapitalizationType=UITextAutocapitalizationTypeAllCharacters;self.keyField.autocorrectionType=UITextAutocorrectionTypeNo;self.keyField.backgroundColor=[UIColor colorWithRed:.12 green:.17 blue:.24 alpha:1];self.keyField.textColor=UIColor.whiteColor;self.keyField.layer.cornerRadius=12;self.keyField.leftView=[[UIView alloc]initWithFrame:CGRectMake(0,0,12,1)];self.keyField.leftViewMode=UITextFieldViewModeAlways;
 self.activateButton=[UIButton buttonWithType:UIButtonTypeSystem];self.activateButton.translatesAutoresizingMaskIntoConstraints=NO;self.activateButton.backgroundColor=[UIColor colorWithRed:.15 green:.72 blue:.83 alpha:1];self.activateButton.layer.cornerRadius=12;[self.activateButton setTitle:@"KÍCH HOẠT" forState:UIControlStateNormal];[self.activateButton setTitleColor:UIColor.blackColor forState:UIControlStateNormal];[self.activateButton addTarget:self action:@selector(activate) forControlEvents:UIControlEventTouchUpInside];
 self.statusLabel=[UILabel new];self.statusLabel.translatesAutoresizingMaskIntoConstraints=NO;self.statusLabel.textColor=UIColor.whiteColor;self.statusLabel.numberOfLines=0;self.statusLabel.textAlignment=NSTextAlignmentCenter;
 for(UIView *v in @[title,subtitle,self.keyField,self.activateButton,self.statusLabel])[self.view addSubview:v];
 UILayoutGuide *g=self.view.safeAreaLayoutGuide;
 [NSLayoutConstraint activateConstraints:@[[title.topAnchor constraintEqualToAnchor:g.topAnchor constant:65],[title.leadingAnchor constraintEqualToAnchor:g.leadingAnchor constant:20],[title.trailingAnchor constraintEqualToAnchor:g.trailingAnchor constant:-20],[subtitle.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:8],[subtitle.centerXAnchor constraintEqualToAnchor:title.centerXAnchor],[self.keyField.topAnchor constraintEqualToAnchor:subtitle.bottomAnchor constant:45],[self.keyField.leadingAnchor constraintEqualToAnchor:g.leadingAnchor constant:22],[self.keyField.trailingAnchor constraintEqualToAnchor:g.trailingAnchor constant:-22],[self.keyField.heightAnchor constraintEqualToConstant:50],[self.activateButton.topAnchor constraintEqualToAnchor:self.keyField.bottomAnchor constant:16],[self.activateButton.leadingAnchor constraintEqualToAnchor:self.keyField.leadingAnchor],[self.activateButton.trailingAnchor constraintEqualToAnchor:self.keyField.trailingAnchor],[self.activateButton.heightAnchor constraintEqualToConstant:48],[self.statusLabel.topAnchor constraintEqualToAnchor:self.activateButton.bottomAnchor constant:20],[self.statusLabel.leadingAnchor constraintEqualToAnchor:self.keyField.leadingAnchor],[self.statusLabel.trailingAnchor constraintEqualToAnchor:self.keyField.trailingAnchor]]];
}
- (void)activate { NSString *key=[self.keyField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];self.activateButton.enabled=NO;self.statusLabel.text=@"Đang xác thực...";
 [[NVLicenseManager shared]verifyKey:key completion:^(BOOL valid,NSString *message,NSDate *expires){self.activateButton.enabled=YES;self.statusLabel.text=message;if(valid && expires) { [[NSUserDefaults standardUserDefaults]setObject:key forKey:@"NV_LAST_LICENSE_KEY"]; if(self.onActivated)self.onActivated(expires); }}];
}
@end
