#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export THEOS="${THEOS:-$HOME/theos}"
if [ ! -f "$THEOS/makefiles/common.mk" ]; then
  echo "Theos not found at $THEOS" >&2
  exit 1
fi
if ! find "$THEOS/sdks" -maxdepth 1 -name 'iPhoneOS*.sdk' -print -quit | grep -q .; then
  echo "No iPhoneOS SDK under $THEOS/sdks" >&2
  exit 1
fi
make clean
make -j1 messages=yes 2>&1 | tee build.log
mkdir -p output
find .theos/obj -name 'FreeFireVN.dylib' -type f -print | head -1 | while IFS= read -r dylib; do cp "$dylib" output/FreeFireVN.dylib; done
if [ ! -f output/FreeFireVN.dylib ]; then echo 'No dylib output found' >&2; exit 1; fi
echo 'Built: output/FreeFireVN.dylib'
