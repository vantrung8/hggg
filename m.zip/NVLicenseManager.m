#import "NVLicenseManager.h"
#import <UIKit/UIKit.h>
#import <Security/Security.h>
static NSString * const kVerifyURL = @"https://ntrungiosvn.shopaccvt.site/license/verify.php";
@implementation NVLicenseManager
+ (instancetype)shared { static NVLicenseManager *obj; static dispatch_once_t once; dispatch_once(&once, ^{ obj=[NVLicenseManager new]; }); return obj; }
- (NSString *)deviceIdentifier {
 NSString *service=@"vn.ntrung.license.device";
 NSDictionary *query=@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:service,(__bridge id)kSecAttrAccount:@"device",(__bridge id)kSecReturnData:@YES,(__bridge id)kSecMatchLimit:(__bridge id)kSecMatchLimitOne};
 CFTypeRef data=NULL; OSStatus status=SecItemCopyMatching((__bridge CFDictionaryRef)query,&data);
 if(status==errSecSuccess && data) { NSString *idstr=[[NSString alloc]initWithData:(__bridge_transfer NSData *)data encoding:NSUTF8StringEncoding]; if(idstr.length>=16)return idstr; }
 NSString *idstr=[NSUUID UUID].UUIDString;
 NSDictionary *add=@{(__bridge id)kSecClass:(__bridge id)kSecClassGenericPassword,(__bridge id)kSecAttrService:service,(__bridge id)kSecAttrAccount:@"device",(__bridge id)kSecValueData:[idstr dataUsingEncoding:NSUTF8StringEncoding],(__bridge id)kSecAttrAccessible:(__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly};
 SecItemAdd((__bridge CFDictionaryRef)add,NULL); return idstr;
}
- (void)verifyKey:(NSString *)key completion:(void (^)(BOOL, NSString *, NSDate *))completion {
 NSURL *url=[NSURL URLWithString:kVerifyURL];
 if(!url || ![url.scheme isEqualToString:@"https"]) { dispatch_async(dispatch_get_main_queue(),^{completion(NO,@"Chưa cấu hình HTTPS API",nil);});return; }
 NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:url];request.HTTPMethod=@"POST";request.timeoutInterval=12;
 [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
 NSDictionary *payload=@{@"key":key?:@"",@"device_id":[self deviceIdentifier]};
 request.HTTPBody=[NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
 [[[NSURLSession sharedSession]dataTaskWithRequest:request completionHandler:^(NSData *data,NSURLResponse *response,NSError *error){
  NSDictionary *obj=nil; if(data)obj=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
  BOOL ok= !error && [response isKindOfClass:[NSHTTPURLResponse class]] && ((NSHTTPURLResponse*)response).statusCode==200 && [obj isKindOfClass:[NSDictionary class]] && [obj[@"ok"] boolValue];
  NSDate *expires=ok?[NSDate dateWithTimeIntervalSince1970:[obj[@"expires_at"] doubleValue]]:nil;
  NSInteger statusCode=[response isKindOfClass:[NSHTTPURLResponse class]]?((NSHTTPURLResponse*)response).statusCode:0;
  NSString *serverError=[obj[@"error"] isKindOfClass:[NSString class]]?obj[@"error"]:nil;
  NSString *msg=ok?@"Kích hoạt thành công":(error?error.localizedDescription:(serverError?:[NSString stringWithFormat:@"Lỗi API HTTP %ld (không có JSON)",(long)statusCode]));
  dispatch_async(dispatch_get_main_queue(),^{completion(ok,msg,expires);});
 }] resume];
}
@end
