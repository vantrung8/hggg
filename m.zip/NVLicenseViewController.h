#import <UIKit/UIKit.h>
@interface NVLicenseViewController : UIViewController
@property(nonatomic,strong) UILabel *statusLabel;
@property(nonatomic,copy) void (^onActivated)(NSDate *expires);
@end
