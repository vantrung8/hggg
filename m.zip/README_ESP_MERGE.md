# NTRUNG VN / ZCMING ESP renderer integration

- Replaced ESPLayer drawing implementation with ZCMING-style corner boxes, tracers, text, health bars and enemy counter.
- Kept NTRUNG existing player-data collection, projection, offsets, AIMBOT, license and UI.
- Skeleton is NOT included: NTRUNG target data only has head/foot; a real skeleton requires actual joint coordinates.
- This is a renderer port, not a full replacement of ZCMING memory-reading engine.
- Not compiled/tested on iOS or Free Fire; back up before use.
- Build: make clean && make package FINALPACKAGE=1 2>&1 | tee build.log
