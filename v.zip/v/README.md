# FreeFireVN — Codespaces source archive

Original project files were extracted unchanged from the user's uploaded ZIP. No game behavior or memory manipulation logic was modified. Build has not been tested in this environment.

## Build on GitHub Codespaces

Theos must already be installed with an iPhoneOS SDK and a compatible iOS cross-compiler. For example, when Theos is installed at `/home/codespace/theos`:

```bash
cd /workspaces/fps/hggg
export THEOS=/home/codespace/theos
chmod +x build.sh
./build.sh
```

Output: `output/FreeFireVN.dylib`. Compilation logs: `build.log`.

This archive intentionally omits `.theos` build intermediates and old `.rar` files.
